<?php $__env->startSection('title','የተጫራች ዝርዝር መረጃ'); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

<div class="pcoded-content">
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <div class="page-header-title">
                        <h5 class="m-b-10">የተጫራች ዝርዝር መረጃ</h5>
                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/"><i class="feather icon-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#!">የተጫራች ዝርዝር መረጃ</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-12">
        <div class="card">
            <div class="card-header">
                <h5>የተጫራች ዝርዝር መረጃ</h5>
                <?php echo $__env->make('layouts.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <div class="card-body">
                <form>
                    <h3 class="mt-2" id="bidder-info-title">የተጫራቾች የግል ዝርዝር መረጃዎች</h3>
                    <div id="bidder-info-form">
                        <div class="row ">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="inputState">ጣቢያ</label>
                                    <div class="alert alert-dark" role="alert">
                                        <?php echo e($bidder->station->name); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="receipt_number">የደረሰኝ ቁጥር</label>
                                    <div class="alert alert-dark" role="alert">
                                        <?php echo e($bidder->receipt_number); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="full_name">ስም</label>
                                    <div class="alert alert-dark" role="alert">
                                        <?php echo e($bidder->first_name); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="full_name">የአባት ስም</label>
                                    <div class="alert alert-dark" role="alert">
                                        <?php echo e($bidder->middle_name); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="full_name">የአያት ስም</label>
                                    <div class="alert alert-dark" role="alert">
                                        <?php echo e($bidder->last_name); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="phone">ስልክ ቁጥር</label>
                                    <div class="alert alert-dark" role="alert">
                                        <?php echo e($bidder->phone); ?>

                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="gender">ጾታ</label>
                                    <div class="alert alert-dark" role="alert">
                                        <?php echo e($bidder->gender); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="gender">ጾታ</label>
                                    <div class="alert alert-dark" role="alert">
                                        <?php echo e($bidder->gender); ?>

                                    </div>
                                </div>
                            </div>
                            </div>
                            <div class="row">
                            <h3 class="mt-2" id="bidder-info-title">ግለሰቡ በደረሰኝ ቁጥር  <?php echo e($bidder->receipt_number); ?> የተወዳደረበት የ ቤት መረጃ</h3>
                            </div>
                           
                            <div id="bidder-info-form">
                        <div class="row ">
                            <?php $__currentLoopData = $bidder->houses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $house): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="phone">ክፍለ ከተማ/ወረዳ </label>
                                    <div class="alert alert-dark" role="alert">
                                        <?php echo e($house->sub_city_wereda); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="phone">የሳይት ስም</label>
                                    <div class="alert alert-dark" role="alert">
                                        <?php echo e($house->site_name); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="phone">የህንፃ ቁጥር</label>
                                    <div class="alert alert-dark" role="alert">
                                        <?php echo e($house->building_number); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="phone">የቤት ቁጥር</label>
                                    <div class="alert alert-dark" role="alert">
                                        <?php echo e($house->house_number); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="phone">ጠቅላላ ስፋት</label>
                                    <div class="alert alert-dark" role="alert">
                                        <?php echo e($house->total_house_area); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="phone">በካሬ መነሻ ዋጋ</label>
                                    <div class="alert alert-dark" role="alert">
                                        <?php echo e($house->initial_price_per_square); ?>

                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="phone">ግለሰቡ ለቤቱ ያስገባው የካሬ መነሻ ዋጋ</label>
                                    <div class="alert alert-dark" role="alert">
                                        <?php echo e($bidder->price_per_square); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="phone">ግለሰቡ ለቤቱ ያስገባው ጠቅላላ ዋጋ</label>
                                    <div class="alert alert-dark" role="alert">
                                        <?php echo e($bidder->total_price); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="phone">ግለሰቡ ያስገባው የ ሲፒኦ መጠን</label>
                                    <div class="alert alert-dark" role="alert">
                                        <?php echo e($bidder->cpo_amount); ?>

                                    </div>
                                </div>
                            </div>
                            <?php if($bidder->rank): ?>
                            <div class="col-md-6">
                            <div class="form-group">
                                <label for="phone">ደረጃ</label>
                               
                                    <div class="alert alert-dark" role="alert">
                                        <?php echo e($bidder->rank); ?>

                                    </div>
                               
                            </div>
                           
                        </div>
                        <?php endif; ?>
                        <?php if($bidder->reason): ?>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="phone">ውድቅ የሆነበት ምክንያት</label>
                               
                                    <div class="alert alert-dark" role="alert">
                                        <?php echo e($bidder->reason); ?>

                                    </div>
                               
                            </div>
                           
                        </div>
                        <?php endif; ?>
                        <?php if($bidder->special_reason): ?>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="phone">ውድቅ የሆነበት ምክንያት/special /</label>
                                
                                    <div class="alert alert-dark" role="alert">
                                        <?php echo e($bidder->special_reason); ?>

                                    </div>
                              
                            </div>
                           
                        </div>
                        <?php endif; ?>
                        </div>

                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moham\Desktop\New folder\IRCBAMIS\IRCBAMIS\resources\views/admin/bidders/show.blade.php ENDPATH**/ ?>