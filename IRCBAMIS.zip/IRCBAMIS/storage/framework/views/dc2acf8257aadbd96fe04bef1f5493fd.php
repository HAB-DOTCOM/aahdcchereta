<?php $__env->startSection('title','የሚና መረጃ ማዘመኛ'); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <div class="page-header-title">
                        <h5 class="m-b-10">የሚና መረጃ ማዘመኛ</h5>
                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/"><i class="feather icon-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#!">የሚና መረጃ ማዘመኛ</a></li>
                    </ul> <br> <br>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5>የሚና መረጃ ማዘመኛ</h5>
                    <?php echo $__env->make('layouts.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="card-body table-border-style">
                    <div class="container">
                        <form action="<?php echo e(route('roles.update',$role->id)); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12">

                                    <div class="form-group">
                                        <label for="name">Name:</label>
                                        <input value="<?php echo e($role->name); ?>" type="text" class="form-control" placeholder="name" name="name" />
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div class="form-group">
                                        <strong>Permissions:</strong>
                                        <br /><br />
                                        <div class="row">
                                            <?php
                                            $permissions = $permission->toArray();
                                            $totalPermissions = count($permissions);
                                            $permissionsPerColumn = ceil($totalPermissions / 3);

                                            $columnCount = 0;
                                            ?>

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-xs-4 col-sm-4 col-md-4">
                                                <label>
                                                    <input type="checkbox" name="permission[]" value="<?php echo e($value['id']); ?>" <?php if(in_array($value['id'], $rolePermissions)): ?> checked <?php endif; ?>> <?php echo e($value['name']); ?>

                                                </label>
                                            </div>
                                            <?php $columnCount++; if ($columnCount === $permissionsPerColumn || $loop->last) { $columnCount = 0; echo '</div>';
                                                if (!$loop->last) {
                                                    echo '<div class="row">';
                                                        }
                                                    }
                                            ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>

                                <div>
                                    <button class="btn btn-raised btn-primary waves-effect" onclick="this.form.submit()" type="submit">አዘምን</button>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/IRCBAMIS/resources/views/admin/roles/edit.blade.php ENDPATH**/ ?>