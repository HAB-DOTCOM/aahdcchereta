<?php $__env->startSection('title','ዳሽቦርድ'); ?>
<?php $__env->startSection('css'); ?>
<link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <div class="page-header-title">
                        <h5 class="m-b-10">ዳሽቦርድ</h5>
                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/"><i class="feather icon-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#!">ዳሽቦርድ</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="mb-3">ቤቶች</h5>
                    <h2><?php echo e($houses); ?><span class="text-muted m-l-5 f-14"></span></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="mb-3">ተጫራቾች</h5>
                    <h2><?php echo e($bidders); ?><span class="text-muted m-l-5 f-14"></span></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="mb-3">የቤቶች ምድቦች</h5>
                    <h2><?php echo e($housescategory); ?><span class="text-muted m-l-5 f-14"></span></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="mb-3">የሲስተም ተጠቃሚዎች</h5>
                    <h2><?php echo e($users); ?><span class="text-muted m-l-5 f-14"></span></h2>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <?php echo $chart->container(); ?>

        </div>
        <div class="col-md-6">
            <?php echo $chart2->container(); ?>

        </div>

    </div>
</div>

<?php $__env->startSection('javascript'); ?>
<script src="<?php echo e($chart->cdn()); ?>"></script>
<script src="<?php echo e($chart2->cdn()); ?>"></script>

<?php echo e($chart->script()); ?>

<?php echo e($chart2->script()); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moham\Desktop\IRCBAMIS\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>