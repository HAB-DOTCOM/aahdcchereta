<?php $__env->startSection('title','አዲስ ሚና መጨመሪያ'); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <div class="page-header-title">
                        <h5 class="m-b-10">አዲስ ሚና መጨመሪያ</h5>
                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/"><i class="feather icon-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#!">አዲስ ሚና መጨመሪያ</a></li>
                    </ul> <br> <br>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5>አዲስ ሚና መጨመሪያ</h5>
                    <?php echo $__env->make('layouts.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="card-body table-border-style">
                    <div class="container">
                        <form method="POST" action="<?php echo e(route('roles.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12">

                                    <div class="form-group">
                                        <label for="name">ስም:</label>
                                        <input type="text" class="form-control" placeholder="የሚና ስም" name="name" />
                                    </div>
                                </div>
                                <div class="row">
                                    <?php if($permission->isNotEmpty()): ?>
                                    <?php
                                    $totalPermissions = count($permission);
                                    $permissionsPerColumn = ceil($totalPermissions / 3);
                                    $columnCount = 1;
                                    ?>

                                    <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>
                                                <input type="checkbox" name="permission[]" value="<?php echo e($perm->id); ?>" class="name">
                                                <?php echo e($perm->name); ?>

                                            </label><br>
                                        </div>
                                    </div>


                                    <?php if(($key + 1) % $permissionsPerColumn === 0 || $key === $totalPermissions - 1): ?>
                                    <?php $columnCount++; ?>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <p>ምንም ፈቃዶች የሉም።</p>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>

                                <div>
                                    <button class="btn btn-raised btn-primary waves-effect" onclick="this.form.submit()" type="submit">አስገባ</button>
                                </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moham\Desktop\New folder\IRCBAMIS\IRCBAMIS\resources\views/admin/roles/create.blade.php ENDPATH**/ ?>