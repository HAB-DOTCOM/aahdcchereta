<?php $__env->startSection('title','የተጫራች መረጃ ማስተካከያ'); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

<div class="pcoded-content">
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <div class="page-header-title">
                        <h5 class="m-b-10">የተጫራች መረጃ ማስተካከያ</h5>
                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/"><i class="feather icon-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#!">የተጫራች መረጃ ማስተካከያ</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-12">
        <div class="card">
            <div class="card-header">
                <h5>የተጫራች መረጃ ማስተካከያ</h5>
                <?php echo $__env->make('layouts.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <div class="card-body">
                <form method="POST" action="<?php echo e(route('bidders.store', $bidder->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <h3 class="mt-2" id="bidder-info-title">የተጫራች የግል መረጃዎችን ያርትዑ</h3>
                    <div id="bidder-info-form">
                        <div class="row ">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="inputState">ጣቢያ</label>
                                    <select name="biider_station_id" id="inputState" class="form-control">
                                        <option selected>ጣቢያ ምረጥ</option>
                                        <?php $__currentLoopData = $stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e($category->id == $bidder->biider_station_id ? 'selected' : ''); ?> value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="receipt_number">የደረሰኝ ቁጥር</label>
                                    <input type="text" name="receipt_number" value="<?php echo e($bidder->receipt_number); ?>" id="receipt_number" class="form-control" placeholder="የደረሰኝ ቁጥር">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="full_name">ሙሉ ስም</label>
                                    <input type="text" name="full_name" value="<?php echo e($bidder->full_name); ?>" id="full_name" class="form-control" placeholder="ሙሉ ስም">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="phone">ስልክ ቁጥር</label>
                                    <input type="text" name="phone" value="<?php echo e($bidder->phone); ?>" id="phone_number" class="form-control" placeholder="ስልክ ቁጥር">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="gender">ጾታ</label>
                                    <select name="gender" id="gender" class="form-control custom-select">
                                        <option selected>ጾታን ይምረጡ</option>
                                        <option <?php echo e($bidder->gender == 'Male' ? 'selected' : ''); ?> value="Male">ወንድ</option>
                                        <option <?php echo e($bidder->gender == 'Female' ? 'selected' : ''); ?> value="Female">ሴት</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">አዘምን</button>

                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/IRCBAMIS/resources/views/admin/bidders/edit.blade.php ENDPATH**/ ?>