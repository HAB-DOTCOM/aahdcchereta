
<?php $__env->startSection('title', 'Updated Bidders'); ?>

<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <div class="page-header-title">
                        <h5 class="m-b-10">በተጠቃሚው የዘመኑ ተጫራቾች ዝርዝር</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Display date and count of updated bidders above the table -->
    <div class="row">
        <div class="col-md-12">
            <?php $__currentLoopData = $updatedBiddersByDate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $bidders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-primary" role="alert">
                    <strong>Date: <?php echo e($date); ?></strong> - Updated Bidders Count: <?php echo e($bidders->count()); ?>

                </div>
                <div class="table-responsive">
                    <table id="bidders-table-<?php echo e($loop->index); ?>" class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>ተ.ቁ.</th>
                                <th>ስም</th>
                                <th>የአባት ስም</th>
                                <th>የአያት ስም</th>
                                <th>ጾታ</th>
                                <th>አካል ጉዳይ?</th>
                                <th>መነሻ ዋጋ</th>
                                <th>የደረሰኝ ቁጥር</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $bidders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bidder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($bidder->first_name); ?></td>
                                    <td><?php echo e($bidder->middle_name); ?></td>
                                    <td><?php echo e($bidder->last_name); ?></td>
                                    <td><?php echo e($bidder->gender); ?></td>
                                    <td><?php echo e($bidder->is_disabled ? 'አዎ' : 'አይ'); ?></td>
                                    <td><?php echo e($bidder->price_per_square); ?></td>
                                    <td><?php echo e($bidder->receipt_number); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<!-- Include DataTables JavaScript -->
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function() {
        // Initialize DataTable for each table
        <?php $__currentLoopData = $updatedBiddersByDate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $bidders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            $('#bidders-table-<?php echo e($loop->index); ?>').DataTable();
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<!-- Include DataTables CSS -->
<link href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moham\Desktop\New folder\IRCBAMIS\IRCBAMIS\resources\views/admin/user/updated_bidders.blade.php ENDPATH**/ ?>