<?php $__env->startSection('title','ተጫራቾች'); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <div class="page-header-title">
                        <h5 class="m-b-10">ተጫራቾች</h5>
                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/"><i class="feather icon-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#!">ተጫራቾች</a></li>
                    </ul> <br> <br>
                    <a href="<?php echo e(route('admin.bidders.update')); ?>" class="btn  btn-primary">ተጫራች ለማዘመን</a>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5>ተጫራቾች</h5>
                    <?php echo $__env->make('layouts.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="card-body table-border-style">
                    <div class="table-responsive table-bordered">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ተ.ቁ.</th>
                                    <th>ሙሉ ስም</th>
                                    <th>ጾታ</th>
                                    <th>ደረሰኝ ቁጥር</th>
                                    <th>ጣቢያ</th>
                                    <th>ድርጊት</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $bidders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$bidder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($bidder->full_name); ?></td>
                                    <td><?php echo e($bidder->gender); ?></td>
                                    <td><?php echo e($bidder->receipt_number); ?></td>
                                    <td><?php echo e($bidder->station->name); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('bidders.edit', $bidder->id)); ?>" class="btn btn-sm btn-success">ለአርትዖት</a>
                                        <a href="<?php echo e(route('bidders.show', $bidder->id)); ?>" class="btn btn-sm btn-success">ለማየት</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <p>ምንም አልተገኘም።</p>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <div class="d-flex justify-content-center">
                            <?php echo e($bidders->links('pagination::bootstrap-4')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/IRCBAMIS/resources/views/admin/bidders/index.blade.php ENDPATH**/ ?>