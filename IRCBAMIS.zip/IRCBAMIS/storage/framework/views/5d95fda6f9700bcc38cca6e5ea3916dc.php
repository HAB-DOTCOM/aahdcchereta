<?php $__env->startSection('title','ቤቶች'); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <div class="page-header-title">
                        <h5 class="m-b-10">ቤቶች</h5>
                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/"><i class="feather icon-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#!">ቤቶች</a></li>
                    </ul> <br> <br>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('houses-create')): ?>
                    <a href="<?php echo e(route('admin.housecategory.create')); ?>" class="btn  btn-primary">አዲስ ለመዝገብ</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5>ቤቶች</h5>
                    <?php echo $__env->make('layouts.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="card-body table-border-style">
                    <div class="table-responsive table-bordered">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ተ.ቁ.</th>
                                    <th>የሕንፃ ቁጥር</th>
                                    <th>ክፍለ ከተማ / ወረዳ</th>
                                    <th>የሳይት ስም</th>
                                    <th>የቤት ቁጥር</th>
                                    <th>ድርጊት</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $houses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$house): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($house->building_number); ?></td>
                                    <td><?php echo e($house->sub_city_wereda); ?></td>
                                    <td><?php echo e($house->site_name); ?></td>
                                    <td><?php echo e($house->house_number); ?></td>
                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('houses-create')): ?>
                                        <a href="<?php echo e(route('admin.updateHouse', $house->id)); ?>" class="btn btn-sm btn-success">Edit</a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('houses-view')): ?>
                                        <a href="<?php echo e(route('admin.showHouse', $house->id)); ?>" class="btn btn-sm btn-success">Show</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <p>ምንም አልተገኘም።</p>
                                </tr>
                                <?php endif; ?>

                            </tbody>
                        </table>
                        <div class="d-flex justify-content-center">
                            <?php echo e($houses->links('pagination::bootstrap-4')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/IRCBAMIS/resources/views/admin/houses/index.blade.php ENDPATH**/ ?>