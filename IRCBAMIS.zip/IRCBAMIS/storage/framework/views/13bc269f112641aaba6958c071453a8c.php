
<?php $__env->startSection('title', 'House and Bidders'); ?>

<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <div class="page-header-title">
                        <h5 class="m-b-10">House Information</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <!-- Print button -->
                    <div class="text-right">
                        <a href= "<?php echo e(route('printHouseAndBidders',$house->id)); ?>" class="btn btn-primary">Print</a>
                    </div>
                    <h5 class="card-title">የቤቱ መረጃ</h5>
                    <div class="house-info">
                        <div class="row">
                            <div class="col-md-4">
                                <p><strong>የቤቱ ምድብ:</strong> <?php echo e($house->houseCategory->name); ?></p>
                            </div>
                            <div class="col-md-4">
                                <p><strong>የቤቱ ክፍለ ከተማ /ወረዳ :</strong> <?php echo e($house->sub_city_wereda); ?></p>
                            </div>
                            <div class="col-md-4">
                                <p><strong>የቤቱ ሳይት:</strong> <?php echo e($house->site_name); ?></p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <p><strong>የቤቱ ሕንፃ ቁጥር :</strong> <?php echo e($house->building_number); ?></p>
                            </div>
                            <div class="col-md-4">
                                <p><strong>የቤቱ ቁጥር :</strong> <?php echo e($house->house_number); ?></p>
                            </div>
                            <div class="col-md-4">
                                <p><strong>የቤቱ ጠቅላላ ስፋት :</strong> <?php echo e($house->total_house_area); ?></p>
                            </div>
                        </div>
                        <p><strong>በካሬ መነሻ ዋጋ :</strong> <?php echo e($house->initial_price_per_square); ?></p>
                    </div>

                    <h5 class="card-title">የተጫራቾች ዝርዝር</h5>
                    <div class="table-responsive">
                        <table id="bidders-table" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>ተ.ቁ.</th>
                                   
                                    <th style="width: 33.33%;">ስም</th>
                                <th style="width: 33.33%;">የአባት ስም</th>
                                <th style="width: 33.33%;">የአያት ስም</th>
                                    <th>ጾታ</th>
                                    <th>አካል ጉዳይ?</th>
                                    <th>መነሻ ዋጋ</th>
                                    <th>ደረጃ</th>
                                    <th>የደረሰኝ ቁጥር</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $bidders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$bidder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e($key+1); ?></td>
                          
                                    <td><?php echo e($bidder->first_name); ?></td>
                                    <td><?php echo e($bidder->middle_name); ?></td>
                                    <td><?php echo e($bidder->last_name); ?></td>
                                    <td><?php echo e($bidder->gender); ?></td>
                                    <td><?php echo e($bidder->is_disabled ? 'አዎ' : 'አይ'); ?></td>
                                    <td><?php echo e($bidder->price_per_square); ?></td>
                                    <td>
                                    <?php if($bidder->rank === null): ?>
                                        <?php if($bidder->special_reason !== null): ?>
                                            በኮሚቴ ውድቅ 
                                        <?php else: ?>
                                            በሲስተም ውድቅ
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php echo e($bidder->rank); ?>

                                    <?php endif; ?>
                                </td>
                                    <td><?php echo e($bidder->receipt_number); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

           
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <!-- Include DataTables JavaScript -->
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            // Initialize DataTable
            $('#bidders-table').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- Include DataTables CSS -->
    <link href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moham\Desktop\New folder\IRCBAMIS\IRCBAMIS\resources\views/admin/bidders/house_bidders.blade.php ENDPATH**/ ?>