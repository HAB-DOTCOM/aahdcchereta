<?php $__env->startSection('title', 'ተጫራቾች'); ?>
<?php $__env->startSection('css'); ?>
    <!-- Include DataTables CSS -->
    <link href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <style>
        /* Custom styling for DataTables */
        #bidders-table_wrapper .dataTables_length,
        #bidders-table_wrapper .dataTables_filter {
            margin-bottom: 10px;
            text-align: right;
        }

        #bidders-table_paginate {
            float: right;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <div class="page-header-title">
                        <h5 class="m-b-10">ተጫራቾች</h5>
                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/"><i class="feather icon-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#!">ተጫራቾች</a></li>
                    </ul> <br> <br>
                    <a href="<?php echo e(route('bidders.create')); ?>" class="btn  btn-primary">አዲስ ለመመዝገብ</a>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5>ተጫራቾች</h5>
                    <?php echo $__env->make('layouts.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="card-body table-border-style">
                    <div class="table-responsive table-bordered">
                        <table id="bidders-table" class="table table-hover">
                        <thead>
                            <tr>
                                <th>ተ.ቁ.</th>
                                <th style="width: 33.33%;">ስም</th>
                                <th style="width: 33.33%;">የአባት ስም</th>
                                <th style="width: 33.33%;">የአያት ስም</th>
                                <th>ጾታ</th>
                                <th>ደረሰኝ ቁጥር</th>
                                <th>ጣቢያ</th>
                                <th>ድርጊት</th>
                            </tr>
                        </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $bidders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$bidder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($bidder->first_name); ?></td>
                                    <td><?php echo e($bidder->middle_name); ?></td>
                                    <td><?php echo e($bidder->last_name); ?></td>
                                    <td><?php echo e($bidder->gender); ?></td>
                                    <td><?php echo e($bidder->receipt_number); ?></td>
                                    <td><?php echo e($bidder->station->name); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('bidders.edit', $bidder->id)); ?>" class="btn btn-sm btn-success">ለአርትዖት</a>
                                        <a href="<?php echo e(route('bidders.show', $bidder->id)); ?>" class="btn btn-sm btn-success">ለማየት</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6">ምንም አልተገኘም።</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="d-flex justify-content-center">
                            <?php echo e($bidders->links('pagination::bootstrap-4')); ?>

                        </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <!-- Include DataTables JavaScript -->
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            // Initialize DataTable
            $('#bidders-table').DataTable({
                
         
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moham\Desktop\New folder\IRCBAMIS\IRCBAMIS\resources\views/admin/bidders/index.blade.php ENDPATH**/ ?>