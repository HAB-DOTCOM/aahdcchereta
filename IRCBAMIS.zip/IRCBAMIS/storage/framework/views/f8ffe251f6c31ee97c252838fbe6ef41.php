<?php $__env->startSection('title', 'ብቁ ያልሆኑ ተጫራቶች'); ?>
<?php $__env->startSection('css'); ?>
<!-- Include DataTables CSS -->
<link href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <div class="page-header-title">
                        <h5 class="m-b-10">ብቁ ያልሆኑ ተጫራቶች</h5>
                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/"><i class="feather icon-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#!">ብቁ ያልሆኑ ተጫራቶች</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5>ብቁ ያልሆኑ ተጫራቶች</h5>
                    <?php echo $__env->make('layouts.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="card-body table-border-style">
                    <div class="table-responsive table-bordered">
                        <table id="bidder-table" class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ተ.ቁ.</th>
                                    <th style="width: 33.33%;">ስም</th>
                                    <th style="width: 33.33%;">የአባት ስም</th>
                                    <th style="width: 33.33%;">የአያት ስም</th>
                                    <th>የደረሰኝ ቁጥር</th>
                                    <th>የተጫረቱበት የቤት ቁጥር</th>
                                    <th>ብቁ ያልሆነበት ምክንያት</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $specialReasonBidders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$bidder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($bidder->first_name); ?></td>
                                    <td><?php echo e($bidder->middle_name); ?></td>
                                    <td><?php echo e($bidder->last_name); ?></td>
                                    <td><?php echo e($bidder->receipt_number); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $bidder->houses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $house): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($house->house_number); ?><br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><?php echo e(Str::limit($bidder->special_reason, 50)); ?></td>
                                    
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5">ምንም አልተገኘም።</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="d-flex justify-content-center">
                            <?php echo e($specialReasonBidders->links('pagination::bootstrap-4')); ?>

                        </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<!-- Include DataTables JavaScript -->
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
<script>
    $(document).ready(function() {
        // Initialize DataTable
        $('#bidder-table').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moham\Desktop\New folder\IRCBAMIS\IRCBAMIS\resources\views/admin/bidders/disqualified_bidders.blade.php ENDPATH**/ ?>