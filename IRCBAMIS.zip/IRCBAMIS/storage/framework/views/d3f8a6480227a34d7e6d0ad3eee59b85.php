<nav class="pcoded-navbar  ">
    <div class="navbar-wrapper  ">
        <div class="navbar-content scroll-div ">
            <div class="">
                <div class="main-menu-header">
                    <img class="img-radius" src="/assets/images/avatar.png" alt="User-Profile-Image">
                    <div class="user-details">
                        <span><?php echo e(Auth::user()->name); ?></span>
                        <div id="more-details">አድሚን<i class="fa fa-chevron-down m-l-5"></i></div>
                    </div>
                </div>
                <div class="collapse" id="nav-user-link">
                    <ul class="list-unstyled">
                        <li class="list-group-item"><a href="<?php echo e(route('admin.profile')); ?>"><i class="feather icon-user m-r-5"></i>ግለ ገፅ</a></li>
                    </ul>
                </div>
            </div>
            <ul class="nav pcoded-inner-navbar ">
                <li class="nav-item">
                    <a href="/" class="nav-link "><span class="pcoded-micon"><i class="fa-solid fa-gauge"></i></span><span class="pcoded-mtext">ዳሽቦርድ</span></a>
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('houses-categories-view')): ?>
                <li class="nav-item pcoded-hasmenu">
                    <a href="#!" class="nav-link "><span class="pcoded-micon"><i class="fa-solid fa-folder-tree"></i></span><span class="pcoded-mtext">የቤት ምድቦች</span></a>
                    <ul class="pcoded-submenu">
                        <li><a href="<?php echo e(route('admin.housecategories')); ?>">ሁሉንም ለማየት</a></li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('houses-categories-create')): ?>
                        <li><a href="<?php echo e(route('admin.housecategory.create')); ?>">አዲስ ለመመዝገብ</a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('houses-view')): ?>
                <li class="nav-item pcoded-hasmenu">
                    <a href="#!" class="nav-link "><span class="pcoded-micon"><i class="fa-solid fa-house-chimney-window"></i></span><span class="pcoded-mtext">ቤቶች</span></a>
                    <ul class="pcoded-submenu">
                        <li><a href="<?php echo e(route('admin.houses')); ?>">ሁሉንም ለማየት</a></li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('houses-create')): ?>
                        <li><a href="<?php echo e(route('admin.house.create')); ?>">አዲስ ለመመዝገብ</a></li>
                        <li><a href="<?php echo e(route('import.houses.form')); ?>">የመኖሪያ ቤቶች በብዛት ለመመዝገብ</a></li>
                        <li><a href="<?php echo e(route('mimport.houses.form')); ?>">የንግድ ቤቶች በብዛት ለመመዝገብ</a></li>
                        <li><a href="<?php echo e(route('admin.nobidder')); ?>">ምንም ተጫራች የሌላቸው ቤቶች</a></li>
                        <li><a href="<?php echo e(route('admin.onebidder')); ?>">1 ተጫራች ብቻ ያላቸው ቤቶች</a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('station-view')): ?>
                <li class="nav-item pcoded-hasmenu">
                    <a href="#!" class="nav-link "><span class="pcoded-micon"><i class="fa-solid fa-location-dot"></i></span><span class="pcoded-mtext">ጣቢያዎች</span></a>
                    <ul class="pcoded-submenu">
                        <li><a href="<?php echo e(route('admin.bidderstation')); ?>">ሁሉንም ለማየት</a></li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('station-create')): ?>
                        <li><a href="<?php echo e(route('admin.BidderStation.create')); ?>">አዲስ ለመመዝገብ</a></li>
                        <?php endif; ?>

                    </ul>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-bidder')): ?>
                <li class="nav-item pcoded-hasmenu">
                    <a href="#!" class="nav-link "><span class="pcoded-micon"><i class="fa-solid fa-money-bill-trend-up"></i></span><span class="pcoded-mtext">ተጫራቾች</span></a>
                    <ul class="pcoded-submenu">
                        <li><a href="<?php echo e(route('admin.bidders')); ?>">ሁሉንም ለማየት</a></li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-bidder')): ?>
                        <li><a href="<?php echo e(route('bidders.create')); ?>">አዲስ ለመመዝገብ</a></li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-bidder')): ?>
                        <li><a href="<?php echo e(route('admin.bidders.update')); ?>">ተጫራች ለማዘመን</a></li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-bidders-topBidders')): ?>
                        <li><a href="<?php echo e(route('admin.topBidders')); ?>">አሸናፊ ተጫራቾች</a></li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-bidders-disqualifiedBidders-system')): ?>
                        <li><a href="<?php echo e(route('disqualifiedBidders')); ?>">በሲስተም ውድቅ የተደረጉ ተጫራቾች</a></li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-bidder')): ?>
                        <li><a href="<?php echo e(route('import.bidders.form')); ?>">በብዛት ለመመዝገብ</a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-view')): ?>
                <li class="nav-item pcoded-hasmenu">
                    <a href="#!" class="nav-link "><span class="pcoded-micon"><i class="fa-solid fa-users"></i></span><span class="pcoded-mtext">ተጠቃሚዎች</span></a>
                    <ul class="pcoded-submenu">
                        <li><a href="<?php echo e(route('admin.users')); ?>">ሁሉንም ለማየት</a></li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-create')): ?>
                        <li><a href="<?php echo e(route('admin.user.create')); ?>">አዲስ ለመመዝገብ</a></li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-view')): ?>
                        <li><a href="<?php echo e(route('roles.index')); ?>">የተጠቃሚዎች ሚና</a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('disqualified-bidders-view')): ?>
                <li class="nav-item pcoded-hasmenu">
                    <a href="#!" class="nav-link "><span class="pcoded-micon"><i class="fa-solid fa-file-excel"></i></span><span class="pcoded-mtext">በኮሚቴ ውድቅ የተደረጉ ተጫራቾች</span></a>
                    <ul class="pcoded-submenu">
                        <li><a href="<?php echo e(route('admin.specialdisqualifiedbidders')); ?>">ሁሉንም ለማየት</a></li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('disqualified-bidders-update')): ?>
                        <li><a href="<?php echo e(route('admin.specialdisqualifiedbidders.update.form')); ?>">አዲስ ለመመዝገብ</a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('agreement-accesss')): ?>
                <li class="nav-item pcoded-hasmenu">
                    <a href="#!" class="nav-link "><span class="pcoded-micon"><i class="fa-solid fa-file-contract"></i></span><span class="pcoded-mtext">ውል</span></a>
                    <ul class="pcoded-submenu">
                        <li><a href="<?php echo e(route('admin.agreements')); ?>">ሁሉንም ለማየት</a></li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('agreement-create')): ?>
                        <li><a href="<?php echo e(route('admin.agreement.create')); ?>">አዲስ ለማዋዋል</a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>

                <li class="nav-item pcoded-hasmenu">
                    <a href="#!" class="nav-link "><span class="pcoded-micon"><i class="fa-solid fa-gear"></i></span><span class="pcoded-mtext">መቼት</span></a>
                    <ul class="pcoded-submenu">
                        <li><a href="<?php echo e(route('admin.profile')); ?>">ግለ ገፅ</a></li>
                        <li><a href="<?php echo e(route('password')); ?>">የይልፈ ቃል</a></li>
                        <li><a href="<?php echo e(route('updated.bidders')); ?>">ግለ ክንውኖች</a></li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('log-access')): ?>
                        <li><a href="<?php echo e(route('admin.logs')); ?>">ክንውኖች</a></li>
                        <?php endif; ?>
                    </ul>
                </li>
            </ul>

        </div>
    </div>
</nav><?php /**PATH C:\Users\moham\Desktop\New folder\IRCBAMIS\IRCBAMIS\resources\views/partials/_navbar.blade.php ENDPATH**/ ?>