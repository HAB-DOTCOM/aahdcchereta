<?php if($errors->any()): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="alert alert-danger">
    <button type="button" aria-hidden="true" class="close" onclick="this.parentElement.style.display='none'">×</button>
    <span>
        <b> ስህተት - </b>
        <?php echo e($error); ?></span>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(session('success')): ?>
<div class="alert alert-success">
    <button type="button" aria-hidden="true" class="close" onclick="this.parentElement.style.display='none'">×</button>
    <span>
        <b> ተሳክቷል - </b> <?php echo e(session('success')); ?></span>
</div>
<?php endif; ?>
<?php if(session('infoMsg')): ?>
<div class="alert alert-warning">
    <button type="button" aria-hidden="true" class="close" onclick="this.parentElement.style.display='none'">×</button>
    <span>
        <b> መረጃ - </b> <?php echo e(session('infoMsg')); ?></span>
</div>
<?php endif; ?><?php /**PATH C:\Users\moham\Desktop\New folder\IRCBAMIS\IRCBAMIS\resources\views/layouts/msg.blade.php ENDPATH**/ ?>