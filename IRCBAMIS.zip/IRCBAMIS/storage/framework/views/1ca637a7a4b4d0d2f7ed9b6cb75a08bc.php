<?php $__env->startSection('title','የተጫራቾች በብዛት መመዝገቢያ'); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <div class="page-header-title">
                        <h5 class="m-b-10">የተጫራቾች በብዛት መመዝገቢያ</h5>
                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/"><i class="feather icon-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#!">የተጫራቾች በብዛት መመዝገቢያ</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-12">
        <div class="card">
            <div class="card-header">
                <h5>የተጫራቾች በብዛት መመዝገቢያ </h5>
                <?php echo $__env->make('layouts.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <form action="<?php echo e(route('import.bidders')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="inputState">ጣቢያ</label>
                                <select name="bidder_station_id" id="inputState" class="form-control">
                                    <option selected>ጣቢያ ምረጥ</option>
                                    <?php $__currentLoopData = $stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">ፋይል ጫን</label>
                                <small>ፋይሉ xls ወይም xlsx መሆን አለበት።</small>
                                <input type="file" name="file" required class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Category Name">
                            </div>

                            <button type="submit" class="btn  btn-primary">መዝግብ</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moham\Desktop\New folder\IRCBAMIS\IRCBAMIS\resources\views/import/bidder_form.blade.php ENDPATH**/ ?>