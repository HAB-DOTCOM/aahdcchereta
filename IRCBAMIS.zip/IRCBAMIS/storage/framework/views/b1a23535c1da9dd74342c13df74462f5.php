<?php $__env->startSection('title','ሚናዎች'); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <div class="page-header-title">
                        <h5 class="m-b-10">ሚናዎች</h5>
                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/"><i class="feather icon-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#!">ሚናዎች</a></li>
                    </ul> <br> <br>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-create')): ?>
                    <a href="<?php echo e(route('roles.create')); ?>" class="btn  btn-primary">አዲስ ለመጨመር</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5>ሚናዎች</h5>
                    <?php echo $__env->make('layouts.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="card-body table-border-style">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ተ.ቁ.</th>
                                    <th>ስም</th>
                                    <th>ድርጊት</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key + 1); ?></td>
                                    <td><?php echo e($role->name); ?></td>
                                    <td>
                                        <a class="btn btn-sm btn-success" href="<?php echo e(route('roles.show',$role->id)); ?>">ለማየት</a>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-edit')): ?>
                                        <a class="btn btn-sm btn-success" href="<?php echo e(route('roles.edit',$role->id)); ?>">ለአርትዖት</a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-delete')): ?>
                                        <form id="delete-form-<?php echo e($role->id); ?>" action="<?php echo e(route('roles.destroy',$role->id)); ?>" style="display: none;" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                        </form>
                                        <button type="button" class="btn btn-sm btn-danger" onclick="if(confirm('Are you sure? You want to delete this?')){
                                                                                                event.preventDefault();
                                                                                                document.getElementById('delete-form-<?php echo e($role->id); ?>').submit();
                                                                                            }else {
                                                                                                event.preventDefault();
                                                                                                    }"><i class="fas fa-trash"></i>ለመሰረዝ</button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/IRCBAMIS/resources/views/admin/roles/index.blade.php ENDPATH**/ ?>