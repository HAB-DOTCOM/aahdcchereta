<?php $__env->startSection('title','የቤቶች በብዛት መመዝገቢያ'); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <div class="page-header-title">
                        <h5 class="m-b-10">የቤቶች በብዛት መመዝገቢያ</h5>
                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/"><i class="feather icon-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#!">የቤቶች በብዛት መመዝገቢያ</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-12">
        <div class="card">
            <div class="card-header">
                <h5>የቤቶች በብዛት መመዝገቢያ </h5>
                <?php echo $__env->make('layouts.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- Loading animation -->
                <div id="loading-overlay" style="display: none;">
                    <div id="loading-content">
                        <video width="100%" height="100%" autoplay loop>
                            <source src="<?php echo e(asset('AuctionManagement/assets/loading/istockphoto-1302436594-640_adpp_is.mp4')); ?>" type="video/mp4">
                            Your browser does not support the video tag.
                        </video>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <form id="importForm" action="<?php echo e(route('mimport.houses')); ?>" method="post" enctype="multipart/form-data">

                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="inputState">የቤት ምድብ</label>
                                <select name="category_id" id="inputState" class="form-control">
                                    <option selected>ምድብ መረጥ</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">ፋይል ጫን</label>
                                <small>ፋይሉ xls ወይም xlsx መሆን አለበት።</small>
                                <input type="file" name="file" required class="form-control" id="file" aria-describedby="emailHelp" placeholder="Category Name">
                            </div>

                            <button type="submit" class="btn  btn-primary">መዝግብ</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moham\Desktop\IRCBAMIS\resources\views/import/mhouses_form.blade.php ENDPATH**/ ?>