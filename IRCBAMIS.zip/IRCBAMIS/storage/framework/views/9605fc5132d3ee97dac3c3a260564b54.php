<?php $__env->startSection('title', 'ከፍተኛ ተጫራቾች'); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <div class="page-header-title">
                        <h5 class="m-b-10">ከፍተኛ ተጫራቾች</h5>
                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/"><i class="feather icon-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#!">ከፍተኛ ተጫራቾች</a></li>
                    </ul> <br> <br>
                    <a href="<?php echo e(route('print.results')); ?>" class="btn  btn-primary">አትም</a>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5>ከፍተኛ ተጫራቾች (1-3 ደረጃ)</h5>
                    <?php echo $__env->make('layouts.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="card-body table-border-style">

                    <div class="table-responsive table-bordered">

                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>የቤት ቁጥር</th>
                                    <th>አሸናፊ ተጫራቾች</th>
                                    <!-- <th>ድርጊት</th> -->
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $houses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $house): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($house->house_number); ?></td>
                                    <td>
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>ደረጃ</th>
                                                    <th>ሙሉ ስም</th>
                                                    <th>ጾታ</th>
                                                    <th>አካል ጉዳይ?</th>
                                                    <th>መነሻ ዋጋ</th>
                                                    <th>የደረሰኝ ቁጥር</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $house->bidders->take(100); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bidder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($bidder->rank); ?></td>
                                                    <td><?php echo e($bidder->full_name); ?></td>
                                                    <td><?php echo e($bidder->gender); ?></td>
                                                    <td><?php echo e($bidder->is_disabled ? 'Yes' : 'No'); ?></td>
                                                    <td><?php echo e($bidder->price_per_square); ?></td>
                                                    <td><?php echo e($bidder->receipt_number); ?></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </td>
                                    <!-- <td>
                                        <a href="" class="btn btn-sm btn-success">Edit</a>
                                        <a href="" class="btn btn-sm btn-success">Show</a>
                                    </td> -->
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            </tbody>
                        </table>
                        <div class="d-flex justify-content-center">
                            <?php echo e($houses->links('pagination::bootstrap-4')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->startSection('javascript'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/IRCBAMIS/resources/views/admin/bidders/top_bidders.blade.php ENDPATH**/ ?>