<?php $__env->startSection('title','አዲስ ጣቢያ ለመጨመር '); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- [ breadcrumb ] start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-12">
                    <div class="page-header-title">
                        <h5 class="m-b-10">አዲስ ጣቢያ ለመጨመር</h5>
                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/"><i class="feather icon-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#!">አዲስ ጣቢያ ለመጨመር</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-12">
        <div class="card">
            <div class="card-header">
                <h5>አዲስ ጣቢያ ለመጨመር</h5>
                <?php echo $__env->make('layouts.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <form action="<?php echo e(route('admin.createBidderStation')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="exampleInputEmail1">የምዝገባ ጣቢያ ስም</label>
                                <input type="text" name="name" required class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="የምዝገባ ጣቢያ ስም">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail11">የምዝገባ ጣቢያ ስም</label>
                                <input type="text" name="description" required class="form-control" id="exampleInputEmail11" aria-describedby="emailHelp" placeholder="የምዝገባ ጣቢያ ስም">
                            </div>
                            <button type="submit" class="btn  btn-primary">አስገባ</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moham\Desktop\IRCBAMIS\resources\views/admin/stations/create.blade.php ENDPATH**/ ?>