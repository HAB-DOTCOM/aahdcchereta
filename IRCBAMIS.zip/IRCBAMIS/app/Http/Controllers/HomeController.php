<?php

namespace App\Http\Controllers;

use App\Charts\HouseCategoryChart;
use App\Charts\MonthlyBiddersChart;
use App\Models\Bidder;
use App\Models\House;
use App\Models\HousesCategory;
use App\Models\Log;
use App\Models\User;
use Illuminate\Http\Request;
use ArielMejiadev\LarapexCharts\LarapexChart;
use Carbon\Carbon;
use DB;
use Illuminate\Support\Facades\Auth;


class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(HouseCategoryChart $chart, MonthlyBiddersChart $chart2)
    {
        try {

            $bidders = Bidder::whereNotNull('updated_at') // Updated_at is not null
                ->where(DB::raw('DATE(created_at)'), '!=', DB::raw('DATE(updated_at)')) // Created_at date is different from Updated_at date
                ->whereBetween(DB::raw('DATE(updated_at)'), [Carbon::now()->subDays(15)->format('Y-m-d'), Carbon::now()->format('Y-m-d')]) // Updated_at is within the last 15 days
                ->select(DB::raw('DATE(updated_at) as date'), DB::raw('count(*) as count'))
                ->groupBy('date')
                ->get();
            // Prepare chart data
            $labels = [];
            $series = [[
                'name' => 'ዕለታዊ ተጫራቾች',
                'data' => [],
            ]];

            foreach ($bidders as $bidder) {
                $labels[] = $bidder->date;
                $series[0]['data'][] = $bidder->count;
            }

            $chart2 = new LarapexChart;
            $chart2->setType('bar');
            $chart2->setLabels($labels);
            $chart2->setDataset($series);
            $chart2->setTitle('ባለፉት 30 ቀናት ውስጥ ዕለታዊ ተጫራቾች');
            $houses = House::all()->count();
            $logs = Log::all()->count();
            $users = User::all()->count();
            $bidders = Bidder::all()->count();
            $biddersCount = Bidder::whereNotNull('updated_by')->count();
            $categoryName1 = "የንግድ ቤቶች";
            $categoryName2 = "የመኖሪያ ቤቶች";

            // Retrieve category IDs based on names
            $category1 = HousesCategory::where('name', $categoryName1)->first();
            $category2 = HousesCategory::where('name', $categoryName2)->first();
            $housesWithNoBidders = House::whereDoesntHave('bidders')->count();
            // Count houses for category 1
            $countCategory1 = House::where('category_id', $category1->id)->count();
            $housesWithOneBidder = House::has('bidders', '=', 1)->count();
            // Count houses for category 2
            $countCategory2 = House::where('category_id', $category2->id)->count();

            $housescategory = HousesCategory::all()->count();
            return view('admin.dashboard', [
                'chart' => $chart->build(),
                'chart2' => $chart2,
                'houses' => $houses,
                'logs' => $logs,
                'users' => $users,
                'bidders' => $bidders,
                'housescategory' => $housescategory,
                'countCategory1' => $countCategory1,
                'countCategory2' => $countCategory2,
                'housesWithNoBidders' => $housesWithNoBidders,
                'housesWithOneBidder' => $housesWithOneBidder,
                'biddersCount' => $biddersCount,

            ]);
        } catch (\Throwable $th) {
            return redirect()->back();
        }
    }

    public function updatedBiddersByUser()
    {
        // Retrieve the logged-in user
        $user = Auth::user();

        // Query the database to fetch the list of updated bidders by the logged-in user for each day
        $updatedBidders = Bidder::where('updated_by', $user->id)
            ->whereDate('updated_at', '>=', Carbon::now()->subDays(7)) // Adjust as needed, here it fetches data for the last 7 days
            ->orderBy('updated_at', 'desc')
            ->get();

        // Group the updated bidders by date
        $updatedBiddersByDate = $updatedBidders->groupBy(function ($item) {
            return $item->updated_at->toDateString();
        });

        // You can then pass $updatedBiddersByDate to your view for displaying

        return view('admin.user.updated_bidders', compact('updatedBiddersByDate'));
    }
}
