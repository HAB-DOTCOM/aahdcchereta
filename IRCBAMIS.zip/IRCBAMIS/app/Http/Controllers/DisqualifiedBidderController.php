<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Bidder;
use App\Models\House;
use App\Models\Log;
use App\Models\HousesCategory;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class DisqualifiedBidderController extends Controller
{
    public function __construct()
    {
        // Apply middleware for specific permissions
        $this->middleware('permission:disqualified-bidders-view', ['only' => ['index']]);
        $this->middleware('permission:disqualified-bidders-update', ['only' => ['updateForm', 'disqualifiedBidderWithSpecialReason']]);
    }
    public function index()
    {
        try {
            $specialReasonBidders = Bidder::where('special_reason', '<>', 'Disqualified')->paginate(1);
            return view('admin.bidders.disqualified_bidders', compact('specialReasonBidders'));
        } catch (\Throwable $th) {
            return redirect()->back();
        }
        // Fetch all bidders with a special reason
    }

    public function updateForm()
    {
        try {
            $bidderNumbers = Bidder::pluck('receipt_number');
            $categories = HousesCategory::all();
            return view('admin.bidders.disqualified_bidders_update_form', compact('bidderNumbers', 'categories'));
        } catch (\Throwable $th) {
            //throw $th;
        }
    }

  
      

    public function disqualifiedBidderWithSpecialReason(Request $request)
    {
        Log::create([
            'id' => Str::uuid(),
            'action' => 'updated Bidder  receipt_number '.$request->input('receipt_number'),
            'user_id' => Auth::id(),
        ]);
        $request->validate([
            'is_disabled' => 'required',
            'house_number' => 'required',
            'price_per_square' => 'required',
            'cpo_amount' => 'required',
            'cpo_number' => 'required',
            'cpo_Bank_branch' => 'required',
            'cpo_Bank_name' => 'required',
            'cpo_person_name' => 'required',
            'cpo_Bank_account' => 'required',
            'special_reason' => 'required',
        ]);
        try {
            DB::beginTransaction();

            $bidder = Bidder::where('receipt_number', $request->input('receipt_number'))->first();
            $selectedHouse = House::where('house_number', $request->input('house_number'))->first();
       // Check if the bidder has already applied for a house
            if ($bidder->house_id) {
                // Detach the bidder from the previous house in the pivot table
                $previousHouse = House::find($bidder->house_id);
                $previousHouse->bidders()->detach($bidder->id);
            }
            $initialPricePerSquare = $selectedHouse->initial_price_per_square;
            $Housetotalarea = $selectedHouse->total_house_area;
            $expectedTotalPrice = $Housetotalarea *  $request->input('price_per_square');
            $expectedCPOAmount = 0.02 * $expectedTotalPrice;
            $reasons = [];
    
            // Compare price_per_square with selected house's initial_price_per_square
            if (bccomp($request->input('price_per_square'), $initialPricePerSquare, 5) < 0) {
                $reasons[] = 'በእያንዳንዱ ካሬ ከቤቱ የመነሻ ዋጋ በታች';
            } elseif (bccomp($request->input('price_per_square'), $initialPricePerSquare, 5) == 0) {
                $reasons[] = 'በእያንዳንዱ ካሬ ከቤቱ የመነሻ ዋጋ ጋር እኩል ነው።';
            }
    
            // Check if CPO amount is below the expected value
            if (bccomp($request->input('cpo_amount'), $expectedCPOAmount, 5) < 0) {
                $reasons[] = 'ከሚጠበቀው ዝቅተኛ CPO መጠን';
            }
    
            // Concatenate reasons using a loop
            $reason = implode('; ', $reasons);
    
            // Set status based on reasons
            $status = 'Disqualified'; // Default status
    
            // Check if the bidder meets any of the qualified conditions
            if (
                (
                    $request->input('price_per_square') > $initialPricePerSquare &&
                    bccomp($request->input('cpo_amount'), $expectedCPOAmount, 5) == 0
                )
                ||
                (
                    $request->input('price_per_square') > $initialPricePerSquare &&
                    bccomp($request->input('cpo_amount'), $expectedCPOAmount, 5) > 0
                )
                ||
                (
                    $request->input('price_per_square') == $initialPricePerSquare &&
                    bccomp($request->input('cpo_amount'), $expectedCPOAmount, 5) == 0
                )
            ) {
                $status = 'Qualified';
            }
    
    
    
            // Update bidder information
            $bidder->fill($request->all() + [
                'total_price' => $expectedTotalPrice,
                'status' => 'Disqualified',
                
                // Concatenate first name, middle name, and last name and save to cpo_person_name
                'cpo_person_name' => $request->input('first_name') . ' ' . $request->input('middle_name') . ' ' . $request->input('last_name'),
            ]);
            $bidder->updated_by = Auth::id(); // Set updated_by to the logged-in user
            $bidder->house_id = $selectedHouse->id;
            $bidder->special_reason = $request->input('special_reason');
            $bidder->save();
    
    
          
            // Attach the bidder to the house in the pivot table
            $selectedHouse->bidders()->attach($bidder->id);
    
            DB::commit();
            return redirect()->route('disqualifiedBidders')->with('success', 'የተጫራች መረጃ ዘምኗል.');
        } catch (\Throwable $e) {
            DB::rollBack();
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
}
