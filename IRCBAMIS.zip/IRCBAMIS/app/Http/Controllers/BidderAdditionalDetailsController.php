<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Bidder;
use App\Models\House;
use App\Models\Log;
use App\Models\HousesCategory;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Models\Station;
use Spatie\LaravelPdf\Facades\PDF;
use Symfony\Component\Process\Exception\ProcessFailedException;
use Symfony\Component\Process\Process;

set_time_limit(900);

use TCPDF;

class MYPDF extends TCPDF
{
    // Header method overriding to customize the header for every page
    public function Header()
    {
        // Define the A4 page width in inches
        $a4_width_inches = 8.27;

        // Convert A4 page width from inches to millimeters
        $a4_width_mm = $a4_width_inches * 25.4;

        // Calculate the proportional width for the header image
        $header_width = $a4_width_mm * 0.8; // Adjust the proportion (0.8) as needed

        // Define the margins as variables for better readability and adjustment
        $margin_left = ($this->GetPageWidth() - $header_width) / 2; // Center the image horizontally
        $margin_top = 5; // The top margin for the header image positioning

        // Calculate the header image height to maintain aspect ratio
        // Assuming you know your image's original size, you can calculate the proportional height
        // Example: If original size is 1900 x 400 (width x height) and you resize width to 275,
        // then new height = (275 * original height) / original width
        $header_height = ($header_width * 400) / 1900; // Adjust 400 and 1900 to your actual image's dimensions

        // Insert the header image
        // Adjust image position and size according to your needs
        $this->Image(public_path('assets\AuctionManagement\assets\header.png'), $margin_left, $margin_top, $header_width, $header_height, 'PNG', '', 'T', false, 300, '', false, false, 0, false, false, false);
    }
}
class BidderAdditionalDetailsController extends Controller
{
    public function __construct()
    {
        // Apply middleware for specific permissions
        $this->middleware('permission:view-bidders-disqualifiedBidders-system', ['only' => ['disqualifiedBidders']]);
        $this->middleware('permission:view-bidders-topBidders', ['only' => ['topBidders']]);
        $this->middleware('permission:view-bidders-list', ['only' => ['index']]);
        $this->middleware('permission:create-bidder', ['only' => ['create', 'store']]);
        $this->middleware('permission:edit-bidder', ['only' => ['edit', 'updatepage', 'update']]);
        $this->middleware('permission:view-bidder', ['only' => ['show']]);
    }

    public function index()
    {
        try {
            // Log the action
            Log::create([
                'id' => Str::uuid(),
                'action' => 'Viewed Bidders list',
                'user_id' => Auth::id(),
            ]);

            $bidders = Bidder::latest('updated_at')->paginate(100);

            return view('admin.bidders.index', compact('bidders'));
        } catch (\Throwable $e) {
            // Handle exception
            return back()->withErrors('Error occurred: ' . $e->getMessage());
        }
    }
    public function create()
    {
        try {
            $stations = Station::all();
            return view('admin.bidders.create', compact('stations'));
        } catch (\Throwable $e) {
            // Handle exception
            return back()->withErrors('Error occurred: ' . $e->getMessage());
        }
    }
    public function edit($id)
    {
        try {
            $stations = Station::all();
            $bidder = Bidder::find($id);
            return view('admin.bidders.edit', compact('stations', 'bidder'));
        } catch (\Throwable $e) {
            // Handle exception
            return back()->withErrors('Error occurred: ' . $e->getMessage());
        }
    }
    public function show($id)
    {
        try {
            $stations = Station::all();
            $bidder = Bidder::find($id);
            return view('admin.bidders.show', compact('stations', 'bidder'));
        } catch (\Throwable $e) {
            // Handle exception
            return back()->withErrors('Error occurred: ' . $e->getMessage());
        }
    }
    public function store(Request $request)
    {
        // Validate request data
        $request->validate([
            'first_name' => 'required',
            'middle_name' => 'required',
            'last_name' => 'required',
            'phone' => 'required',
            'receipt_number' => 'required|unique:bidders',
            'gender' => 'required',
            'biider_station_id' => 'required',
        ]);

        try {
            DB::beginTransaction();

            // Create a new bidder instance
            $bidder = new Bidder();
            $bidder->full_name = $request->input('full_name');
            $bidder->phone = $request->input('phone');
            $bidder->receipt_number = $request->input('receipt_number');
            $bidder->gender = $request->input('gender');
            $bidder->added_by = Auth::id();
            $bidder->biider_station_id = $request->input('biider_station_id');
            $bidder->save();

            DB::commit();

            return redirect()->route('admin.bidders')->with('success', 'ተጫራች ተመዝግቧል.');
        } catch (\Throwable $e) {
            DB::rollBack();
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    public function updatepage()
    {
        // Retrieve all bidder numbers from the database
        $bidderNumbers = Bidder::pluck('receipt_number');
        $categories = HousesCategory::all();
        return view('admin.bidders.update', compact('bidderNumbers', 'categories'));
    }
    public function update(Request $request)
    {
        //   // Check if the logged-in user has already updated the bidder
        //         $previousUpdate = Log::where('action', 'like', '%updated Bidder%')
        //         ->where('user_id', Auth::id())
        //         ->where('action', 'like', '%' . $request->input('receipt_number') . '%')
        //         ->first();

        //     if ($previousUpdate) {
        //     return redirect()->back()->with('error', 'You have already updated this bidder.');
        //     }
        $request->validate([
            'is_disabled' => 'required',
            'house_number' => 'required',
            'price_per_square' => 'required',
            'cpo_amount' => 'required',
            'cpo_number' => 'required',
            'cpo_Bank_branch' => 'required',
            'cpo_Bank_name' => 'required',
            'cpo_person_name' => 'required',
            'cpo_Bank_account' => 'required',
        ]);
        Log::create([
            'id' => Str::uuid(),
            'action' => 'updated Bidder  receipt_number ' . $request->input('receipt_number'),
            'user_id' => Auth::id(),
        ]);
        DB::beginTransaction();

        $bidder = Bidder::where('receipt_number', $request->input('receipt_number'))->first();
        $selectedHouse = House::where('house_number', $request->input('house_number'))->first();
        // Check if the bidder has already applied for a house
        if ($bidder->house_id) {
            // Detach the bidder from the previous house in the pivot table
            $previousHouse = House::find($bidder->house_id);
            $previousHouse->bidders()->detach($bidder->id);
        }
        $initialPricePerSquare = $selectedHouse->initial_price_per_square;
        $Housetotalarea = $selectedHouse->total_house_area;
        $expectedTotalPrice = $Housetotalarea *  $request->input('price_per_square');
        $expectedCPOAmount = 0.02 * $expectedTotalPrice;
        $reasons = [];

        // Compare price_per_square with selected house's initial_price_per_square
        if (bccomp($request->input('price_per_square'), $initialPricePerSquare, 5) < 0) {
            $reasons[] = 'በእያንዳንዱ ካሬ ከቤቱ የመነሻ ዋጋ በታች';
        } elseif (bccomp($request->input('price_per_square'), $initialPricePerSquare, 5) == 0) {
            $reasons[] = 'በእያንዳንዱ ካሬ ከቤቱ የመነሻ ዋጋ ጋር እኩል ነው።';
        }

        // Check if CPO amount is below the expected value
        if (bccomp($request->input('cpo_amount'), $expectedCPOAmount, 2) < 0) {
            $reasons[] = 'ከሚጠበቀው ዝቅተኛ CPO መጠን';
        }

        // Concatenate reasons using a loop
        $reason = implode('; ', $reasons);

        // Set status based on reasons
        $status = 'Disqualified'; // Default status

        // Check if the bidder meets any of the qualified conditions
        if (
            (
                $request->input('price_per_square') > $initialPricePerSquare &&
                bccomp($request->input('cpo_amount'), $expectedCPOAmount, 5) == 0
            )
            ||
            (
                $request->input('price_per_square') > $initialPricePerSquare &&
                bccomp($request->input('cpo_amount'), $expectedCPOAmount, 5) > 0
            )
            ||
            (
                $request->input('price_per_square') == $initialPricePerSquare &&
                bccomp($request->input('cpo_amount'), $expectedCPOAmount, 5) == 0
            )
        ) {
            $status = 'Qualified';
        }



        // Update bidder information
        $bidder->fill($request->all() + [
            'total_price' => $expectedTotalPrice,
            'status' => $status,
            'reason' => $reason,
            // Concatenate first name, middle name, and last name and save to cpo_person_name
            'cpo_person_name' => $request->input('first_name') . ' ' . $request->input('middle_name') . ' ' . $request->input('last_name'),
        ]);
        $bidder->updated_by = Auth::id(); // Set updated_by to the logged-in user
        $bidder->house_id = $selectedHouse->id;
        $bidder->save();



        // Attach the bidder to the house in the pivot table
        $selectedHouse->bidders()->attach($bidder->id);

        DB::commit();

        // Assign rank after updating bidder information
        $this->assignRankForHouse($bidder->house_id);

        return redirect()->route('admin.bidders')->with('success', 'የተጫራች መረጃ ዘምኗል.');
    }
    public function updateinfo(Request $request, $id)
    {

        // Validate request data
        $request->validate([
            'first_name' => 'required',
            'middle_name' => 'required',
            'last_name' => 'required',
            'phone' => 'required',
            'receipt_number' => 'required|unique:bidders,receipt_number,' . $id,
            'gender' => 'required',
            'bidder_station_id' => 'required',
        ]);

        try {
        DB::beginTransaction();

        // Find the bidder by ID
        $bidder = Bidder::findOrFail($id);

        // Check if the new receipt number is unique
        if ($bidder->receipt_number !== $request->input('receipt_number')) {
            $request->validate([
                'receipt_number' => 'unique:bidders',
            ]);
        }

        // Update bidder properties
        $bidder->first_name = $request->input('first_name');
        $bidder->middle_name = $request->input('middle_name');
        $bidder->last_name = $request->input('last_name');
        $bidder->phone = $request->input('phone');
        $bidder->receipt_number = $request->input('receipt_number');
        $bidder->gender = $request->input('gender');
        $bidder->added_by = Auth::id();
        $bidder->bidder_station_id = $request->input('bidder_station_id');
        $bidder->save();

        DB::commit();

        return redirect()->route('admin.bidders')->with('success', 'ተጫራች ተመዝግቧል.');
        } catch (\Throwable $e) {
            DB::rollBack();
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    public function searchReceiptNumbers(Request $request)
    {
        try {
            $search = $request->search;
            $receiptNumbers = Bidder::query()
                ->where('receipt_number', 'LIKE', "%{$search}%")
                ->pluck('receipt_number');

            return response()->json($receiptNumbers);
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    // Method to get bidder details by receipt number
    public function getBidderInfo($receiptNumber)
    {
        $bidder = Bidder::where('receipt_number', $receiptNumber)->first();

        if (!$bidder) {
            return response()->json(['error' => 'Bidder not found'], 404);
        }

        return response()->json([
            'first_name' => $bidder->first_name,
            'middle_name' => $bidder->middle_name,
            'last_name' => $bidder->last_name,
            'gender' => $bidder->gender,
            'phone' => $bidder->phone,
        ]);
    }

    public function getBidderHouseInfo($houseNumber)
    {
        $house = House::where('house_number', $houseNumber)->first();

        if (!$house) {
            return response()->json(['error' => 'House not found'], 404);
        }

        return response()->json([
            'sub_city_wereda' => $house->sub_city_wereda,
            'site_name' => $house->site_name,
            'building_number' => $house->building_number,
            'floor_number' => $house->floor_number,
            'total_house_area' => $house->total_house_area,
            'house_category' => $house->houseCategory->name,
        ]);
    }
    public function assignRankForHouse($houseId)
    {
        // Retrieve qualified bidders for the specified house ordered by total_price in descending order
        $bidders = Bidder::where('house_id', $houseId)
            ->where('status', 'Qualified')
            ->orderBy('total_price', 'desc')
            ->orderBy('is_disabled', 'desc')
            ->orderByRaw("CASE WHEN gender = 'ሴ' THEN 1 ELSE 2 END") // Prioritize female bidders
            ->get();

        // Initialize rank counter
        $rank = 0;

        // Initialize variables to track previous total price and disability status
        $previousTotalPrice = null;
        $previousIsDisabled = null;
        $previousGender = null;

        foreach ($bidders as $bidder) {
            // Increment the rank counter if the total_price, disability status, or gender changes
            if ($bidder->total_price !== $previousTotalPrice || $bidder->is_disabled !== $previousIsDisabled || $bidder->gender !== $previousGender) {
                $rank++;
            }

            // Update previous total price, disability status, and gender
            $previousTotalPrice = $bidder->total_price;
            $previousIsDisabled = $bidder->is_disabled;
            $previousGender = $bidder->gender;

            // Assign the rank to the bidder
            $bidder->rank = $rank;

            // Save the rank to the database
            $bidder->save();
        }
    }



    public function topBidders()
    {
        // Retrieve houses that have at least 3 qualified bidders
        $houses = House::whereHas('bidders', function ($query) {
            $query->where('status', 'Qualified');
        }, '>=', 1)
            ->with(['bidders' => function ($query) {
                $query->where('status', 'Qualified')
                    ->whereIn('rank', [1, 2, 3]) // Filter bidders with ranks 1, 2, and 3
                    ->orderBy('rank');
            }])
            ->paginate(10);

        // Render the Blade view to HTML
        return view('admin.bidders.top_bidders', compact('houses'))->render();
    }


    public function disqualifiedBidders()
    {
        $disqualifiedBidders = Bidder::where('status', 'Disqualified')
            ->whereNull('special_reason') // Filter where special_reason is null
            ->latest()
            ->paginate(100);


        return view('admin.bidders.disqualified_bidders_system', compact('disqualifiedBidders'));
    }




    public function printTopBiddersForHouses()
    {
        // Retrieve houses that have at least 3 qualified bidders
        $houses = House::whereHas('bidders', function ($query) {
            $query->where('status', 'Qualified');
        }, '>=', 1)
            ->with(['bidders' => function ($query) {
                $query->where('status', 'Qualified')
                    ->whereIn('rank', [1, 2, 3]) // Filter bidders with ranks 1, 2, and 3
                    ->orderBy('rank');
            }])
            ->orderBy('site_name') // Order by site name
            ->orderBy('category_id') // Then order by category_id
            ->get();


        // Create a new instance of your custom class that extends TCPDF
        $pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

        // Set document information
        $pdf->SetCreator(PDF_CREATOR);
        $pdf->SetAuthor('Your Name');
        $pdf->SetTitle('Top Bidders for Houses');
        $pdf->SetSubject('Top Bidders for Houses');
        $pdf->SetKeywords('TCPDF, PDF, top bidders, houses');

        // Set default monospaced font
        $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

        // Set margins
        $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT, true);

        // Set auto page breaks
        $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

        // Add a page
        $pdf->AddPage('L', 'A4');

        // // Display the title for the top bidders section
        // $pdf->Ln(1); // Line break to provide some space after the header image
        // $pdf->SetFont('freeserif', '', 14);
        // $pdf->Cell(0, 10, 'የተጫራቾች ጊዚያዊ ውጤት (1-3)', 0, 1, 'C');

        // Initialize a variable to track current site
        $currentSite = null;
        // Initialize a variable to track houses per page
        $housesPerPage = 0;

        // Loop through each house
        foreach ($houses as $house) {
            // Check if the site has changed
            if ($house->site_name != $currentSite) {
                $currentSite = $house->site_name; // Update current site
                // Display the site name before listing the houses
                $pdf->Ln(5); // Add extra space before each site
                $pdf->SetFont('freeserif', '', 12);
                $pdf->Cell(50, 10, 'በ ' . $currentSite . ' ሳይት የሚገኙ የ' . $house->houseCategory->name, 0, 1, 'C');
            }

            // Display house number
            $pdf->Ln(5);
            $pdf->SetFont('freeserif', '', 12);
            $pdf->Cell(0, 10, 'የቤት ቁጥር: ' . $house->house_number, 0, 1, 'L');

            // Display bidders for the house in a table
            $pdf->SetFont('freeserif', '', 10);
            $pdf->Ln(2); // Line break to provide some space after the header image
            $pdf->Cell(0, 10, 'አሸናፊ ተጫራቾች', 0, 1, 'L');

            // Initialize HTML string for content
            $tableHtml = '<table cellspacing="0" cellpadding="4" border="1" style="width:100%;">
                    <thead>
                        <tr>
                            <th>ደረጃ</th>
                            <th>ሙሉ ስም</th>
                            <th>ጾታ</th>
                            <th>አካል ጉዳይ?</th>
                            <th>ጠቅላላ ዋጋ</th>
                            <th>የደረሰኝ ቁጥር</th>
                        </tr>
                    </thead>
                    <tbody>';

            foreach ($house->bidders as $bidder) {
                $tableHtml .= '<tr>
                        <td>' . $bidder->rank . '</td>
                        <td>' . $bidder->full_name . '</td>
                        <td>' . $bidder->gender . '</td>
                        <td>' . ($bidder->is_disabled ? 'Yes' : 'No') . '</td>
                        <td>' . $bidder->total_price . '</td>
                        <td>' . $bidder->receipt_number . '</td>
                    </tr>';
            }

            $tableHtml .= '</tbody></table>';

            // Output the HTML to the PDF
            $pdf->writeHTML($tableHtml, true, false, true, false, '');

            // Increment houses per page counter
            $housesPerPage++;

            // Check if 4 houses have been printed on the current page
            if ($housesPerPage > 4) {
                // Add a page break
                $pdf->AddPage('L', 'A4');
                // Reset houses per page counter
                $housesPerPage = 0;
            }
        }

        // Output the PDF to a browser
        $pdf->Output('top_bidders_for_houses.pdf', 'I');
    }


    public function printHouseAndBidders($houseId)
    {
        $house = House::findOrFail($houseId);

        // Retrieve all bidders of a certain house and order them by their rank
        $bidders = Bidder::where('house_id', $houseId)
            ->orderBy('rank')
            ->get();

        // Create a new instance of MYPDF instead of TCPDF
        $pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

        // Set document information
        $pdf->SetCreator(PDF_CREATOR);
        $pdf->SetAuthor('Your Name');
        $pdf->SetTitle('House and Bidders');
        $pdf->SetSubject('House and Bidders Information');
        $pdf->SetKeywords('TCPDF, PDF, house, bidders');

        // Set default monospaced font
        $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

        // Set margins
        $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT, true);

        // Set auto page breaks
        $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

        // Add a page
        $pdf->AddPage('L', 'A4');

        // Display house information
        $pdf->SetFont('freeserif', '', 12);
        $pdf->Cell(0, 10, 'የቤቱ መረጃ', 0, 1, 'C');
        $pdf->Ln(3);
        $pdf->Cell(0, 6, 'የቤቱ ምድብ: ' . $house->houseCategory->name, 0, 0, 'L');
        $pdf->Cell(0, 6, 'የቤቱ ክፍለ ከተማ /ወረዳ : ' . $house->sub_city_wereda, 0, 1, 'R');
        $pdf->Cell(0, 6, 'የቤቱ ሳይት: ' . $house->site_name, 0, 0, 'L');
        $pdf->Cell(0, 6, 'የቤት ቁጥር: ' . $house->house_number, 0, 1, 'R');
        $pdf->Cell(0, 6, 'የቤቱ ጠቅላላ ስፋት: ' . $house->total_house_area, 0, 0, 'L');
        $pdf->Cell(0, 6, 'በካሬ መነሻ ዋጋ: ' . $house->initial_price_per_square, 0, 1, 'R');

        // Call the Header method to add the custom header
        $pdf->Header();

        // Set Y position before writing HTML content
        $pdf->SetY(60); // Adjust the Y position as needed

        // Display bidders information
        $pdf->SetFont('freeserif', '', 12);
        $pdf->Cell(0, 10, 'የተጫራቾች ዝርዝር', 0, 1, 'C');
        $pdf->Ln(5);

        // Initialize table header
        $html = '<table border="1" cellspacing="0" cellpadding="4"><thead><tr><th>ደረጃ</th><th>ስም</th><th>የአባት ስም</th><th>የአያት ስም</th><th>ጾታ</th><th>አካል ጉዳይ?</th><th>መነሻ ዋጋ</th><th>የደረሰኝ ቁጥር</th></tr></thead><tbody>';

        // Populate table with bidders data
        foreach ($bidders as $bidder) {
            $html .= '<tr>';
            $html .= '<td>';

            if ($bidder->rank === null) {
                if ($bidder->reason !== null) {
                    $html .= 'በኮሚቴ ውድቅ'; // Disqualified by reason
                } elseif ($bidder->special_reason !== null) {
                    $html .= 'በሲስተም ውድቅ'; // Disqualified by special reason
                }
            } else {
                $html .= $bidder->rank;
            }

            $html .= '</td>';
            $html .= '<td>' . $bidder->first_name . '</td>';
            $html .= '<td>' . $bidder->middle_name . '</td>';
            $html .= '<td>' . $bidder->last_name . '</td>';
            $html .= '<td>' . $bidder->gender . '</td>';
            $html .= '<td>' . ($bidder->is_disabled ? 'አዎ' : 'አይ') . '</td>';
            $html .= '<td>' . $bidder->price_per_square . '</td>';
            $html .= '<td>' . $bidder->receipt_number . '</td>';
            $html .= '</tr>';
        }


        $html .= '</tbody></table>';

        // Write HTML content
        $pdf->writeHTML($html, true, false, true, false, '');

        // Output the PDF to a browser
        $pdf->Output('house_and_bidders.pdf', 'I');
    }


    public function getHouseBidders($houseId)
    {
        // Retrieve the house
        $house = House::findOrFail($houseId);
        // Retrieve all bidders of a certain house and order them by their rank
        $bidders = Bidder::where('house_id', $houseId)
            //  ->where('status', 'Qualified') // Filter by status being "Qualified"
            ->orderBy('rank')
            ->get();


        return view('admin.bidders.house_bidders', compact('bidders', 'house'));
    }
}
