<?php

namespace App\Charts;

use App\Models\Bidder;
use ArielMejiaDev\LarapexCharts\LarapexChart;
use Carbon\Carbon;
use DB;

class MonthlyBiddersChart
{
    protected $chart;

    public function __construct(LarapexChart $chart)
    {
        $this->chart = $chart;
    }

    public function build()
    {

        $bidders = Bidder::whereNotNull('updated_at') // Updated_at is not null
            ->where(DB::raw('DATE(created_at)'), '!=', DB::raw('DATE(updated_at)')) // Created_at date is different from Updated_at date
            ->where('updated_at', '>=', Carbon::now()->subDays(15)) // Updated_at is within the last 15 days
            ->select(DB::raw('DATE(updated_at) as date'), DB::raw('count(*) as count'))
            ->groupBy('date')
            ->get();

        // Prepare chart data
        $labels = [];
        $series = [[
            'name' => 'Daily Bidders',
            'data' => [],
        ]];

        foreach ($bidders as $bidder) {
            $labels[] = $bidder->date;
            $series[0]['data'][] = $bidder->count;
        }

        $chart = new LarapexChart;
        $chart->setType('bar');
        $chart->setLabels($labels);
        $chart->setDataset($series);
        $chart->setTitle('Daily Bidders in the Last 15 Days');

        return $chart;
    }
}
