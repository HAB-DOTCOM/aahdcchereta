<?php

namespace App\Imports;

use App\Models\Bidder;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\ToModel;
set_time_limit(600);
class BiddersImport implements ToModel
{
    use Importable;

    protected $added_by;
    protected $bidder_station_id;
    protected $currentRow = 0;
    protected $errors = [];

    public function __construct($bidder_station_id)
    {
        $this->added_by = Auth::id();
        $this->bidder_station_id = $bidder_station_id;
    }

    public function model(array $row)
    {
        // Skip the first row (header)
        if ($this->currentRow == 0) {
            $this->currentRow++;
            return null;
        }


        $validator = Validator::make(['receipt_number' => $row[5]], [
            'receipt_number' => 'unique:bidders',
        ]);

        if ($validator->fails()) {
            $this->errors[] = "Bidder with receipt_number {$row[5]} already exists.";
            return null;
        }

        $this->currentRow++;
        return new Bidder([
            'first_name' => $row[1],
            'middle_name' => $row[2],
            'last_name' => $row[3],
            'gender' => $row[4],
            'receipt_number' => $row[5],
            'phone' => $row[6],
            'added_by' => $this->added_by,
            'status' => "added",
            'bidder_station_id' => $this->bidder_station_id,
        ]);
    }

    public function getErrors()
    {
        return $this->errors;
    }
}
