<?php

return [
    'options' => [
        'isPhpEnabled' => true,
        'isHtml5ParserEnabled' => true,
        'isFontSubsettingEnabled' => true,
        'isRemoteEnabled' => true,
        'isUnicodeEnabled' => true, // Enable Unicode support
    ],
];
